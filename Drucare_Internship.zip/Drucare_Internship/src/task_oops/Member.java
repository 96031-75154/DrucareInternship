package task_oops;

public class Member {

	String name;
	int age;
	long mobile;
	String address;
	double salary;

	public Member(String name, int age, long mobile, String address, double salary) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
		this.address = address;
		this.salary = salary;
	}

	public void printSalary() {
		System.out.println("Salary of the employee : " + salary);
	}
	
	public static void main(String[] args) {
		
		String spec = "Computer Science";
		String des = "Software Developer";
		Employee employee = new Employee("Kiran", 24, 9487438789L, "Guntur", 20000, spec, des);
		employee.printSalary();
		String a = "Information Technology";
		String b = "Testing Engineer";
		Employee employee2 = new Employee("Raju", 23, 9447534759L, "Karimnagar", 23000, a, b);
		employee2.printSalary();
	}
}

class Employee extends Member {
	
	String specialization;
	String department;
	
	public Employee(String name, int age, long mobile, String address, double salary, String specialization,
			String department) {
		super(name, age, mobile, address, salary);
		this.specialization = specialization;
		this.department = department;
	}
}

class Manager extends Member {
	
	String specialization;
	String department;
	public Manager(String name, int age, long mobile, String address, double salary, String specialization,
			String department) {
		super(name, age, mobile, address, salary);
		this.specialization = specialization;
		this.department = department;
	}
}