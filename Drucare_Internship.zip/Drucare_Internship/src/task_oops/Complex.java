package task_oops;

import java.util.Scanner;

public class Complex {
	
	private int real;
	private int imaginary;
	
	public Complex(int real, int imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter real number");
		int real = scanner.nextInt();
		System.out.println("Enter imaginary number");
		int imaginary = scanner.nextInt();
		System.out.println("Addition : "+addition(real, imaginary));
		System.out.println("Substraction :"+difference(real, imaginary));
		System.out.println("Product :"+product(real, imaginary));
	}
	
	static int addition(int a, int b) {
		return a+b;
	}
	static double difference(int a, double b) {
		return a-b;
	}
	static double product(double a, float b) {
		return a*b;
	}
}
