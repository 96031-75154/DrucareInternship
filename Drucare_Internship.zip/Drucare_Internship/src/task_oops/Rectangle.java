package task_oops;import java.awt.geom.Area;

public class Rectangle {

	int length, breadth;
	
	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}

	public double area() {
		return length*breadth;
	}
	
	public static void main(String[] args) {
		Rectangle rectangle = new Rectangle(23, 35);
		System.out.println("Area of rectangle 1 : "+rectangle.area());
		Rectangle rectangle2 = new Rectangle(12, 21);
		System.out.println("Area of rectangle 2 : "+rectangle2.area());
	}
}
