package task_oops;

import java.util.ArrayList;
import java.util.List;

class Bank {
	
	private double interestRate;
	private double minimumBalance;
	private double minimumWithdrawLimit;
	
	public Bank(double interestRate, double minimumBalance, double minimumWithdrawLimit) {
		this.interestRate = interestRate;
		this.minimumBalance = minimumBalance;
		this.minimumWithdrawLimit = minimumWithdrawLimit;
	}
	
	public double getInterest() {
		return interestRate;
	}
}
public class RbiGuidelines {

	public static void main(String[] args) {
		
		List<Bank> banks = new ArrayList<Bank>();
		banks.add(new Bank(4, 2000, 50000));
		banks.add(new Bank(5.5, 3000, 60000));
		banks.add(new Bank(7, 4000, 100000));
		
		for(Bank bank : banks) {
			if(bank.getInterest() <= 4)
				System.out.println("Banks can get upto 4% interest according to RBI guidelines");
			else
				System.out.println("Interest will be charged according to concerned bank");
		}
	}
}