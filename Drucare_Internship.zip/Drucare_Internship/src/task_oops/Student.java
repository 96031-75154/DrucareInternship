package task_oops;

import java.util.ArrayList;
import java.util.List;

public class Student {

	private String name;

	public Student() {
		this.name = name;
	}

	public Student(String name) {
		super();
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public static void main(String[] args) {
		
		Student student = new Student();
		Student student2 = new Student("Pavan");
		System.out.println("Names of Students : ");
		List<Student> list = new ArrayList<Student>();
		list.add(student);
		list.add(student2);
		for(Student stu : list) {
			System.out.println(stu.getName());
		}
	}
}