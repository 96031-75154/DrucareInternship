package java8practice;

interface Shape
{
	void draw();
}

interface Addition
{
	int sum(int a, int b);
}

public class LambdaExpression {
	public static void main(String[] args) {
		print(() -> System.out.println("Rectangle: draw() method"));
		print(() -> System.out.println("Circle: draw() method"));
		print(() -> System.out.println("Square: draw() method"));
		
		Addition addition = (a, b) -> (a+b);
		int result = addition.sum(9, 6);
		System.out.println(result);
		
		Thread thread = new Thread(() -> System.out.println("run method called using lambda expression...."));
		thread.start();
	}
	private static void print(Shape shape) {
		shape.draw();
	}
}